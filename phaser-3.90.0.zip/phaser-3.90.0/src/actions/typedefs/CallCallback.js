/**
 * @callback Phaser.Types.Actions.CallCallback
 * @since 3.0.0
 *
 * @param {Phaser.GameObjects.GameObject} item - The Game Object to run the callback on.
 */
